package br.lawtrel.pdv.Model;

public class loginModel {
  
}
