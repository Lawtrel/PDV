package br.lawtrel.pdv.View;

public class vendasScreen {
}
