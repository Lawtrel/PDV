package br.lawtrel.pdv.Controller;

public class Product {
}
